"""ROS 2 Humble experimental obstacle supervisor. NOT a certified safety controller."""
import math
import struct
import time

import rclpy
from rclpy.node import Node
from rclpy.duration import Duration
from rclpy.time import Time
from rclpy.qos import qos_profile_sensor_data, QoSProfile
from tf2_ros import Buffer, TransformListener, TransformException
from sensor_msgs.msg import PointCloud2, PointField
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Bool


class ObstacleSupervisor(Node):
    def __init__(self):
        super().__init__('obstacle_supervisor')
        defaults = {
            'lidar_topic': '/pixloop/lidar/points',
            'zed_topic': '/zed/zed_node/point_cloud/cloud_registered',
            'requested_topic': '/simulation/cmd_vel_requested',
            'base_frame': 'base_link',
            'corridor_half_width_m': 0.9,
            'z_min_m': -0.2,
            'z_max_m': 1.8,
            'max_range_m': 12.0,
            'stop_distance_m': 1.0,
            'slow_distance_m': 2.5,
            'replan_distance_m': 3.5,
            'hysteresis_m': 0.3,
            'sensor_timeout_s': 1.0,
            'cmd_timeout_s': 1.0,
            'max_sample_points': 12000,
            'min_obstacle_points': 3,
            'accel_limit_mps2': 0.3,
            'control_hz': 10.0,
            'require_both_sensors': True,
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)
        self.p = {name: self.get_parameter(name).value for name in defaults}
        if not (0 < self.p['stop_distance_m'] < self.p['slow_distance_m'] < self.p['replan_distance_m']):
            raise ValueError('Require 0 < stop_distance < slow_distance < replan_distance')
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.sensors = {'lidar': {'last': None, 'distance': math.inf, 'error': 'no messages'},
                        'zed': {'last': None, 'distance': math.inf, 'error': 'no messages'}}
        self.cmd = None
        self.cmd_last = None
        self.last_control = time.monotonic()
        self.prev_linear = 0.0
        self.state = 'FALLA'
        self.replan_active = False
        self.create_subscription(PointCloud2, self.p['lidar_topic'],
                                 lambda msg: self.on_cloud(msg, 'lidar'), qos_profile_sensor_data)
        self.create_subscription(PointCloud2, self.p['zed_topic'],
                                 lambda msg: self.on_cloud(msg, 'zed'), qos_profile_sensor_data)
        self.create_subscription(Twist, self.p['requested_topic'], self.on_cmd, QoSProfile(depth=10))
        # Intentionally separate from physical /cmd_vel and other chassis control topics.
        self.safe_pub = self.create_publisher(Twist, '/simulation/cmd_vel_safe', 10)
        self.state_pub = self.create_publisher(String, '/simulation/obstacle_state', 10)
        self.replan_pub = self.create_publisher(Bool, '/simulation/replan_requested', 10)
        self.create_timer(1.0 / self.p['control_hz'], self.control)
        self.get_logger().warn('MONITOR-ONLY: output is /simulation/cmd_vel_safe; do NOT connect to chassis')

    def on_cmd(self, msg):
        self.cmd = msg
        self.cmd_last = time.monotonic()

    def on_cloud(self, msg, key):
        sensor = self.sensors[key]
        try:
            if not msg.header.frame_id:
                raise ValueError('PointCloud2 without frame_id')
            stamp_ns = int(msg.header.stamp.sec) * 1_000_000_000 + int(msg.header.stamp.nanosec)
            age_s = (self.get_clock().now().nanoseconds - stamp_ns) / 1e9
            if stamp_ns <= 0 or age_s > self.p['sensor_timeout_s'] or age_s < -0.5:
                raise ValueError(f'invalid/stale sensor header timestamp (age={age_s:.2f}s)')
            fields = {f.name: f for f in msg.fields}
            if not all(n in fields for n in ('x', 'y', 'z')):
                raise ValueError('missing x/y/z fields')
            if any(fields[n].datatype != PointField.FLOAT32 for n in ('x', 'y', 'z')):
                raise ValueError('expected float32 x/y/z fields')
            if msg.point_step < max(fields[n].offset for n in ('x', 'y', 'z')) + 4:
                raise ValueError('invalid point_step')
            if msg.width == 0 or msg.height == 0:
                raise ValueError('empty cloud')
            frame = msg.header.frame_id.lstrip('/')
            base = self.p['base_frame'].lstrip('/')
            if frame == base:
                R = (1., 0., 0., 0., 1., 0., 0., 0., 1.)
                t = (0., 0., 0.)
            else:
                trans = self.tf_buffer.lookup_transform(
                    base, frame, Time.from_msg(msg.header.stamp), timeout=Duration(seconds=0.06))
                q = trans.transform.rotation
                norm = math.sqrt(q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w)
                if norm < 1e-9:
                    raise ValueError('invalid TF quaternion')
                x, y, z, w = (q.x/norm, q.y/norm, q.z/norm, q.w/norm)
                R = (1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w),
                     2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w),
                     2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y))
                p = trans.transform.translation
                t = (p.x, p.y, p.z)
            endian = '>' if msg.is_bigendian else '<'
            unpack = struct.Struct(endian + 'f')
            raw = memoryview(msg.data)
            total = msg.width * msg.height
            step = max(1, math.ceil(total / self.p['max_sample_points']))
            candidates = []
            valid = 0
            for index in range(0, total, step):
                row, col = divmod(index, msg.width)
                base_offset = row * msg.row_step + col * msg.point_step
                xyz = []
                for name in ('x', 'y', 'z'):
                    xyz.append(unpack.unpack_from(raw, base_offset + fields[name].offset)[0])
                if not all(math.isfinite(v) for v in xyz):
                    continue
                valid += 1
                px, py, pz = xyz
                bx = R[0]*px + R[1]*py + R[2]*pz + t[0]
                by = R[3]*px + R[4]*py + R[5]*pz + t[1]
                bz = R[6]*px + R[7]*py + R[8]*pz + t[2]
                if (0.0 < bx <= self.p['max_range_m'] and
                    abs(by) <= self.p['corridor_half_width_m'] and
                    self.p['z_min_m'] <= bz <= self.p['z_max_m']):
                    candidates.append(bx)
            if valid == 0:
                raise ValueError('no finite points in sampled cloud')
            candidates.sort()
            required = max(1, int(self.p['min_obstacle_points']))
            sensor['distance'] = candidates[required-1] if len(candidates) >= required else math.inf
            sensor['last'] = time.monotonic()
            sensor['error'] = None
        except (ValueError, IndexError, struct.error, TransformException, OverflowError) as exc:
            sensor['error'] = str(exc)
            sensor['last'] = None  # Fail closed even if previous data were valid.

    def control(self):
        now = time.monotonic()
        dt = min(0.3, max(0.0, now - self.last_control))
        self.last_control = now
        good = []
        bad = []
        for name, data in self.sensors.items():
            if data['last'] is None or now-data['last'] > self.p['sensor_timeout_s']:
                bad.append(f'{name}:{data["error"] or "stale"}')
            else:
                good.append(data['distance'])
        if (self.p['require_both_sensors'] and bad) or not good:
            failure = 'sensores ' + ','.join(bad)
        elif self.cmd_last is None or now-self.cmd_last > self.p['cmd_timeout_s']:
            failure = 'comando ausente/caducado'
        elif not all(math.isfinite(v) for v in (self.cmd.linear.x, self.cmd.angular.z)):
            failure = 'comando no finito'
        elif self.cmd.linear.x < 0 or abs(self.cmd.angular.z) > 1e-3:
            failure = 'reversa/giro no soportados (solo avance recto)'
        else:
            failure = ''
        d = min(good, default=math.inf)
        if failure:
            state = 'FALLA'
        else:
            h = self.p['hysteresis_m']
            stop = self.p['stop_distance_m']
            slow = self.p['slow_distance_m']
            if d <= stop or (self.state == 'PARADA' and d <= stop+h):
                state = 'PARADA'
            elif d <= slow or (self.state == 'DESACELERACION' and d <= slow+h):
                state = 'DESACELERACION'
            else:
                state = 'LIBRE'
        # Replan is an independent request; it does not call Nav2.
        if not failure:
            boundary = self.p['replan_distance_m'] + (self.p['hysteresis_m'] if self.replan_active else 0.0)
            self.replan_active = d <= boundary
        else:
            self.replan_active = False
        out = Twist()
        if state in ('FALLA', 'PARADA'):
            allowed = 0.0
        else:
            requested = max(0.0, self.cmd.linear.x)
            if state == 'DESACELERACION':
                ratio = (d - self.p['stop_distance_m']) / (self.p['slow_distance_m']-self.p['stop_distance_m'])
                requested *= max(0.0, min(1.0, ratio))
            # Braking commands are not ramp-limited; acceleration is ramp-limited.
            allowed = min(requested, self.prev_linear + self.p['accel_limit_mps2']*dt)
        out.linear.x = allowed
        self.prev_linear = allowed
        self.safe_pub.publish(out)
        self.state_pub.publish(String(data=state if not failure else f'FALLA: {failure}'))
        self.replan_pub.publish(Bool(data=self.replan_active))
        if state != self.state or not hasattr(self, '_last_log') or now-self._last_log >= 1.0:
            self.get_logger().info(
                f'LiDAR={self.sensors["lidar"]["distance"]:.2f}m '
                f'ZED={self.sensors["zed"]["distance"]:.2f}m '
                f'd={d:.2f}m estado={state} v_segura={allowed:.2f}m/s '
                f'replan={self.replan_active} {failure}')
            self._last_log = now
        self.state = state


def main(args=None):
    rclpy.init(args=args)
    node = ObstacleSupervisor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
