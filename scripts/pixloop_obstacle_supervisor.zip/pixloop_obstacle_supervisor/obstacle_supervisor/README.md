# Pixloop obstacle_supervisor (ROS 2 Humble, experimental)

Consumes the normalized RoboSense PointCloud2 `/pixloop/lidar/points` and the ZED registered PointCloud2 `/zed/zed_node/point_cloud/cloud_registered`. Both are transformed to `base_link` via TF. Publishes **monitor-only** outputs under `/simulation/`.

## Install
Copy `obstacle_supervisor` into `~/plataforma_challenge/pixloop_challenge_ws/src/`. Then source the standard Pixloop ROS 2 underlays, `export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp`, and:

```
cd ~/plataforma_challenge/pixloop_challenge_ws
colcon build --symlink-install --packages-select obstacle_supervisor
source install/setup.bash
ros2 launch obstacle_supervisor supervisor.launch.py
```

Existing Pixloop drivers/TF launch independently; do not launch them twice. Required: `pixloop_lidar/rslidar_driver.launch.py`, `pixloop_lidar/lidar_launch.py`, `pixloop_tf/sensor_tf_launch.py`, `pixloop_zed/zed_driver.launch.py` (or existing operational bringup equivalents).

## Topics
Input: the two PointCloud2 topics above, plus `geometry_msgs/Twist` on `/simulation/cmd_vel_requested`. Output: `geometry_msgs/Twist` on `/simulation/cmd_vel_safe`, `std_msgs/String` on `/simulation/obstacle_state`, and `std_msgs/Bool` on `/simulation/replan_requested`. This package does not write to `/cmd_vel` or CAN, and `replan_requested` does not call Nav2.

**No requested Twist -> state FALLA and linear speed zero.** For terminal-only testing, start a separate publisher with:

```
ros2 topic pub -r 5 /simulation/cmd_vel_requested geometry_msgs/msg/Twist '{linear: {x: 0.5}}'
```

This is a synthetic command, but **both obstacle sensor inputs are real**.

The supervisor accepts straight forward motion only; reverse and turning requests fail closed. It requires fresh input from both sensors by default. It treats missing TF or malformed clouds as faults, stops immediately on a detected close obstacle, and ramps only increases in allowed speed. `stop/slow/replan` thresholds are **unverified examples only**, not physical braking limits. A single failing sampling or near-ground geometry calibration can cause false results. Subsampling and `min_obstacle_points=3` can miss thin obstacles. Do not connect to the vehicle until braking latency, geometry, TF, thresholds, obstacle cases, and fail-safe architecture are validated with an operator and an E-stop.
