from setuptools import setup
from glob import glob
import os

package_name = 'obstacle_supervisor'
setup(name=package_name, version='0.1.0', packages=[package_name],
      data_files=[('share/ament_index/resource_index/packages', ['resource/' + package_name]),
                  ('share/' + package_name, ['package.xml']),
                  (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
                  (os.path.join('share', package_name, 'config'), glob('config/*.yaml'))],
      install_requires=['setuptools'], zip_safe=True,
      maintainer='Pixloop Team', maintainer_email='team@example.invalid',
      description='Monitor-only fused point cloud obstacle supervisor for Pixloop',
      license='Apache-2.0',
      entry_points={'console_scripts': ['obstacle_supervisor_node = obstacle_supervisor.obstacle_supervisor_node:main']})
