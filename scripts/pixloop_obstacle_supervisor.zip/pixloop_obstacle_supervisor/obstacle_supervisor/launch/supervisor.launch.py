from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    return LaunchDescription([
        Node(package='obstacle_supervisor', executable='obstacle_supervisor_node',
             name='obstacle_supervisor', output='screen',
             parameters=[os.path.join(get_package_share_directory('obstacle_supervisor'),
                                      'config', 'supervisor.yaml')])
    ])
