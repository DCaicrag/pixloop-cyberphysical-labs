# Pixloop Obstacle Supervisor

Sistema de detección y supervisión de obstáculos para la plataforma
Pixloop, desarrollado con ROS 2 Humble.

## Objetivo

Integrar datos reales del LiDAR RoboSense y de la cámara ZED
para detectar obstáculos y generar tres respuestas:

- Solicitar replanificación de ruta.
- Reducir progresivamente la velocidad permitida.
- Solicitar parada cuando un obstáculo esté demasiado cerca.

## Sensores

| Sensor | Tópico |
|--------|--------|
| LiDAR RoboSense | `/pixloop/lidar/points` |
| Cámara ZED | `/zed/zed_node/point_cloud/cloud_registered` |

Ambos sensores utilizan mensajes `sensor_msgs/msg/PointCloud2`.

## Lógica del supervisor

| Distancia | Acción |
|-----------|--------|
| > 6 m | Movimiento libre |
| 4.5–6 m | Movimiento libre y solicitud de replanificación |
| 3–4.5 m | Desaceleración y solicitud de replanificación |
| ≤ 3 m | Parada y solicitud de replanificación |

Los umbrales son experimentales y no están validados
para controlar físicamente el vehículo.

## Instalación

Copiar el paquete `obstacle_supervisor` dentro de `src`
del workspace ROS 2.

Compilar:

```bash
colcon build --symlink-install --packages-select obstacle_supervisor
source install/setup.bash
```

## Ejecución

```bash
ros2 launch obstacle_supervisor supervisor.launch.py
```

## Registro de datos

Los scripts de la carpeta `scripts` permiten iniciar
y detener la adquisición de datos.

```bash
./iniciar_registro.sh
./detener_registro.sh
./ver_resultados.sh
```

## Estado del proyecto

- Integración inicial de LiDAR y ZED.
- Detección de obstáculos mediante nubes de puntos.
- Supervisión de velocidad en modo observación.
- Solicitud de replanificación.
- Registro de decisiones y datos ROS 2.

## Limitaciones conocidas

- Se han observado distancias anómalas próximas a cero.
- Existen fallas por timestamps caducados.
- El supervisor solo evalúa avance recto.
- La replanificación todavía no está conectada a Nav2.
- No está conectado al controlador físico.

**El supervisor es experimental y no constituye
un sistema de seguridad certificado.**