#!/usr/bin/env bash

BASE="$HOME/plataforma_challenge/pruebas_supervisor"
SESSION="pixloop_registro"

if ! tmux has-session -t "$SESSION" 2>/dev/null; then
    echo "No hay una sesión de registro activa."
    exit 1
fi

echo "======================================"
echo " DETENIENDO REGISTRO PIXLOOP"
echo "======================================"

echo "[1/3] Deteniendo velocidad sintética..."
tmux send-keys -t "$SESSION:velocidad" C-c 2>/dev/null || true

sleep 1

echo "[2/3] Finalizando ROS bag..."
tmux send-keys -t "$SESSION:rosbag" C-c 2>/dev/null || true

# Esperar a que ROS bag finalice y escriba metadata.yaml
for i in $(seq 1 30); do
    if ! tmux list-windows -t "$SESSION" -F '#W' 2>/dev/null | grep -qx rosbag; then
        break
    fi
    sleep 1
done

echo "[3/3] Deteniendo supervisor..."
tmux send-keys -t "$SESSION:supervisor" C-c 2>/dev/null || true

sleep 2

RUN=$(cat "$BASE/sesion_actual.txt")

echo
echo "======================================"
echo " RESULTADOS GUARDADOS"
echo "======================================"
echo "Carpeta: $RUN"

if [ -f "$RUN/rosbag/metadata.yaml" ]; then
    echo "ROS bag: metadata.yaml encontrada"
else
    echo "AVISO: verifica el cierre del ROS bag."
fi

if [ -f "$RUN/supervisor.log" ]; then
    echo "Supervisor log: encontrado"
else
    echo "AVISO: no se encontró supervisor.log"
fi

if tmux has-session -t "$SESSION" 2>/dev/null; then
    echo
    echo "AVISO: quedan procesos o ventanas activos."
    echo "Revisa: tmux attach -t $SESSION"
fi

echo
echo "Para analizar:"
echo "./ver_resultados.sh"
