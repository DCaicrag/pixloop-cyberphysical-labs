#!/usr/bin/env bash
set -e

BASE="$HOME/plataforma_challenge/pruebas_supervisor"
SESSION="pixloop_registro"

# Entorno ROS 2
source /opt/ros/humble/setup.bash
source /data/workspaces/pixloop_ros2_ws/install/setup.bash
source /data/workspaces/pixloop_mapping_ws/install/setup.bash
source /data/workspaces/pixloop-sensor-ws/install/setup.bash
source "$HOME/plataforma_challenge/pixloop_challenge_ws/install/setup.bash"

export ROS_DOMAIN_ID=42
export ROS_LOCALHOST_ONLY=0
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp

# Evitar sesiones duplicadas
if tmux has-session -t "$SESSION" 2>/dev/null; then
    echo "Ya existe una sesión de registro."
    exit 1
fi

# Crear carpeta de prueba
RUN="$BASE/prueba_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$RUN"

echo "$RUN" > "$BASE/sesion_actual.txt"

# Supervisor + log
tmux new-session -d -s "$SESSION" -n supervisor \
"ros2 launch obstacle_supervisor supervisor.launch.py 2>&1 | tee '$RUN/supervisor.log'"

# ROS bag
tmux new-window -t "$SESSION" -n rosbag \
"ros2 bag record -o '$RUN/rosbag' \
/simulation/cmd_vel_requested \
/simulation/cmd_vel_safe \
/simulation/obstacle_state \
/simulation/replan_requested \
/pixloop/state_estimation/odom"

# Velocidad sintética
tmux new-window -t "$SESSION" -n velocidad \
"ros2 topic pub -r 10 /simulation/cmd_vel_requested \
geometry_msgs/msg/Twist \
'{linear: {x: 0.5}, angular: {z: 0.0}}'"

echo "========================================"
echo "REGISTRO PIXLOOP INICIADO"
echo "========================================"
echo "Carpeta: $RUN"
echo "Velocidad sintética: 0.5 m/s"
echo "Supervisor: MODO OBSERVACIÓN"
echo
echo "Ver procesos:"
echo "tmux attach -t pixloop_registro"
