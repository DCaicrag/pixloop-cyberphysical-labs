#!/usr/bin/env bash

BASE="$HOME/plataforma_challenge/pruebas_supervisor"

if [ ! -f "$BASE/sesion_actual.txt" ]; then
    echo "No se encontró ninguna sesión."
    exit 1
fi

RUN=$(cat "$BASE/sesion_actual.txt")

if [ ! -f "$RUN/supervisor.log" ]; then
    echo "No existe supervisor.log"
    exit 1
fi

echo "========================================"
echo " ANALISIS DE PRUEBA PIXLOOP"
echo "========================================"
echo "Carpeta: $RUN"
echo

python3 - "$RUN" <<'PY'
import sys
import re
import csv
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone

run = Path(sys.argv[1])

archivo_log = run / "supervisor.log"
archivo_csv = run / "resultados.csv"

patron = re.compile(
    r"LiDAR=(\S+?)m\s+"
    r"ZED=(\S+?)m\s+"
    r"d=(\S+?)m\s+"
    r"estado=(\S+)\s+"
    r"v_segura=(\S+?)m/s\s+"
    r"replan=(True|False)(.*)"
)

columnas = [
    "timestamp_utc",
    "lidar_m",
    "zed_m",
    "distancia_minima_m",
    "estado",
    "velocidad_segura_mps",
    "replanificacion",
    "diagnostico"
]

datos = []

with archivo_log.open(
    "r",
    encoding="utf-8",
    errors="replace"
) as archivo:

    for linea in archivo:

        m = patron.search(linea)

        if not m:
            continue

        tiempo = re.search(
            r"\[(\d{10}\.\d+)\]",
            linea
        )

        fecha = ""

        if tiempo:
            fecha = datetime.fromtimestamp(
                float(tiempo.group(1)),
                timezone.utc
            ).isoformat()

        datos.append([
            fecha,
            m.group(1),
            m.group(2),
            m.group(3),
            m.group(4),
            m.group(5),
            m.group(6),
            m.group(7).strip()
        ])

with archivo_csv.open(
    "w",
    newline="",
    encoding="utf-8"
) as archivo:

    writer = csv.writer(archivo)
    writer.writerow(columnas)
    writer.writerows(datos)

print("RESULTADOS GENERALES")
print("-------------------------------")
print(f"Registros: {len(datos)}")

conteo = Counter(
    fila[4] for fila in datos
)

for estado in [
    "LIBRE",
    "DESACELERACION",
    "PARADA",
    "FALLA"
]:
    cantidad = conteo.get(estado, 0)

    print(f"{estado}: {cantidad}")

replanes = sum(
    fila[6] == "True"
    for fila in datos
)

print(f"Registros con replanificación: {replanes}")

print()
print("ULTIMAS 10 DECISIONES")
print("-------------------------------")

for fila in datos[-10:]:
    print(
        f"d={fila[3]} m | "
        f"{fila[4]} | "
        f"v={fila[5]} m/s | "
        f"replan={fila[6]}"
    )

print()
print("CSV GENERADO:")
print(archivo_csv)

if not datos:
    print(
        "AVISO: no se encontraron líneas "
        "con el formato esperado."
    )

PY

echo
echo "========================================"
echo " ARCHIVOS DISPONIBLES"
echo "========================================"

ls -lh "$RUN"

if [ -d "$RUN/rosbag" ]; then
    echo
    echo "Informacion del ROS bag:"

    source /opt/ros/humble/setup.bash

    ros2 bag info "$RUN/rosbag"
fi

echo
echo "========================================"
echo " ANALISIS FINALIZADO"
echo "========================================"
